<?php
// Run locally after registering and verifying the first administrator's email.
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

if ($argc !== 2 || !filter_var($argv[1], FILTER_VALIDATE_EMAIL)) {
    fwrite(STDERR, "Usage: php scripts/create_admin.php admin@example.com\n");
    exit(1);
}

require_once dirname(__DIR__) . '/config.php';
$email = strtolower(trim($argv[1]));
if ((int)db_value($conn, 'SELECT COUNT(*) FROM users WHERE is_admin=1') > 0) {
    fwrite(STDERR, "An administrator already exists. Use the admin dashboard to manage roles.\n");
    exit(1);
}
$user = db_row($conn, 'SELECT id, is_verified FROM users WHERE email=?', 's', [$email]);
if (!$user || !(int)$user['is_verified']) {
    fwrite(STDERR, "Register and verify this email address before creating the first administrator.\n");
    exit(1);
}
if (db_exec($conn, 'UPDATE users SET is_admin=1 WHERE id=? AND is_verified=1', 'i', [(int)$user['id']]) !== 1) {
    fwrite(STDERR, "Could not create the administrator.\n");
    exit(1);
}
fwrite(STDOUT, "Administrator created. Sign in at admin_login.php using the account email and password.\n");
